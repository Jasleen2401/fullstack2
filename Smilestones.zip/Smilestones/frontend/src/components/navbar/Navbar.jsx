import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import './Navbar.css';

const Navbar = () => {
  const [showDropdown, setShowDropdown] = useState(false);
  const [showPostModal, setShowPostModal] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleResourcesClick = () => {
    setShowDropdown(!showDropdown);
  };

  const handlePostClick = (e) => {
    e.preventDefault();
    setShowPostModal(true);
  };

  return (
    <>
      <nav className={`navbar ${isScrolled ? 'navbar-solid' : 'navbar-transparent'}`}>
        <div className="nav-left">
          <div className="logo">
            <Link to="/home">
              <img src="/logo.png" alt="Smilestones Logo" />
            </Link>
          </div>
          <div className="search-bar">
            <input type="text" placeholder="Search achievements..." />
            <button className="search-btn">🔍</button>
          </div>
        </div>

        <div className="nav-right">
          <Link to="/home" className="nav-item">
            <span className="nav-icon">🏠</span>
            <span>Home</span>
          </Link>

          <Link to="/tasks" className="nav-item">
            <span className="nav-icon">📋</span>
            <span>Tasks</span>
          </Link>

          <Link to="/post" className="nav-item" onClick={handlePostClick}>
            <span className="nav-icon">✏️</span>
            <span>Post</span>
          </Link>

          <Link to="/network" className="nav-item">
            <span className="nav-icon">🌐</span>
            <span>Network</span>
          </Link>

          <Link to="/notifications" className="nav-item">
            <span className="nav-icon">🔔</span>
            <span>Notifications</span>
          </Link>

          <div className="nav-item dropdown">
            <button onClick={handleResourcesClick} className="dropdown-btn">
              <span className="nav-icon">📚</span>
              <span className="nav-text">
                Resources
                <span className={`dropdown-arrow ${showDropdown ? 'open' : ''}`}>▼</span>
              </span>
            </button>
            {showDropdown && (
              <div className="dropdown-content">
                <Link to="/resources/monthly-goals">Monthly Goals</Link>
                <Link to="/resources/top-goals">Top 10 Goals</Link>
                <Link to="/resources/learning">Learning Channels</Link>
                <Link to="/resources/books">My Books</Link>
                <Link to="/resources/movies">My Movies</Link>
                <Link to="/resources/webseries">My Podacsts</Link>
              </div>
            )}
          </div>

          <Link to="/account" className="nav-item">
            <span className="nav-icon">👤</span>
            <span>Account</span>
          </Link>
        </div>
      </nav>

      {showPostModal && (
        <div className="modal-overlay">
          <div className="post-modal">
            <div className="modal-header">
              <h2>Create Post</h2>
              <button className="close-btn" onClick={() => setShowPostModal(false)}>×</button>
            </div>
            <div className="modal-content">
              <textarea placeholder="What's on your mind?" />
              <div className="post-actions">
                <button className="add-photo">
                  <span>📷</span> Add Photo
                </button>
                <button className="post-btn">Post</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default Navbar;