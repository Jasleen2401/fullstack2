import React from 'react';
import './Mission.css';

const Mission = () => {
  return (
    <div className="mission-section">
      <div className="mission-container">
        <div className="mission-left">
          <h2 className="about-title">WhY Smilestones?</h2>
          <h1>There Is All About Smilestones</h1>
          <p className="mission-text">
            "At Smilestones, we believe in the power of tracking and celebrating every achievement. 
            Our platform is designed to help you recognize your progress, share your successes, 
            and build a supportive community of goal-achievers. We're here to make your journey 
            of personal and professional growth more meaningful and enjoyable."
          </p>
          <img src="/signature.png" alt="Signature" className="signature" />
        </div>
        
        <div className="mission-right">
          <div className="feature-box">
            <div className="feature-icon">☕</div>
            <h3>Awesome Progress</h3>
            <p>Track your journey with intuitive progress monitoring and milestone celebrations</p>
          </div>
          
          <div className="feature-box">
            <div className="feature-icon">🌱</div>
            <h3>Goal Varieties</h3>
            <p>Set and achieve various types of goals, from daily tasks to long-term aspirations</p>
          </div>
          
          <div className="feature-box">
            <div className="feature-icon">👍</div>
            <h3>High Quality</h3>
            <p>Experience a premium platform designed for optimal goal tracking and achievement</p>
          </div>
          
          <div className="feature-box">
            <div className="feature-icon">✨</div>
            <h3>Pure Growth</h3>
            <p>Foster continuous improvement and personal development in every step</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Mission;