import React from 'react';
import './Reviews.css';

const Reviews = () => {
  const reviews = [
    {
      name: "Sarah Chen",
      role: "Software Developer",
      review: "Smilestones helped me track my coding journey. From learning new technologies to completing projects, every milestone feels like an achievement.",
      avatar: "/avatars/sarah.jpg"
    },
    {
      name: "James Wilson",
      role: "Fitness Enthusiast",
      review: "The community here is incredibly supportive. Sharing my fitness milestones and seeing others' progress keeps me motivated every day.",
      avatar: "/avatars/james.jpg"
    },
    {
      name: "Maya Patel",
      role: "Student",
      review: "Perfect for keeping track of my academic goals. The ability to break down big goals into smaller milestones makes everything feel achievable.",
      avatar: "/avatars/maya.jpg"
    }
  ];

  return (
    <section className="reviews-section">
      <div className="reviews-container">
        <h2>Learn From Others' Journey</h2>
        <p className="section-subtitle">Discover how others are achieving their goals with Smilestones</p>
        
        <div className="reviews-grid">
          {reviews.map((review, index) => (
            <div key={index} className="review-card">
              <div className="review-header">
                <img src={review.avatar} alt={review.name} className="review-avatar" />
                <div className="review-info">
                  <h3>{review.name}</h3>
                  <span>{review.role}</span>
                </div>
              </div>
              <p className="review-text">{review.review}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Reviews;