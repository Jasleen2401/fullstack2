import React from 'react';
import './AboutUs.css';

const AboutUs = () => {
  return (
    <section className="about-us">
      <div className="about-content">
        <h2>About Smilestones</h2>
        <p className="mission-statement">
          We believe every achievement, no matter how small, deserves to be celebrated.
          Smilestones is your personal space to track, share, and celebrate life's precious moments.
        </p>
        <div className="about-grid">
          <div className="about-card">
            <h3>Our Vision</h3>
            <p>Creating a world where personal growth is celebrated and shared</p>
          </div>
          <div className="about-card">
            <h3>Our Mission</h3>
            <p>Empowering individuals to track and celebrate their journey</p>
          </div>
          <div className="about-card">
            <h3>Our Values</h3>
            <p>Community, Growth, Positivity, and Support</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutUs;