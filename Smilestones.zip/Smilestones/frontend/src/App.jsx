import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Auth from './pages/auth/Auth';

import Home from './pages/home/Home';
import Tasks from './pages/tasks/Tasks'; 

import Navbar from './components/navbar/Navbar';
import './App.css';

function App() {
  return (
    <div className="app-container">
      <Router>
        <Routes>
          <Route path="/" element={<Auth />} />
          
          
          <Route path="/home" element={
            <>
              <Navbar />
              <Home />
            </>
          } />

          <Route path="/tasks" element={
            <>
              <Navbar />
              <Tasks />
            </>
          } />
          
        </Routes>
      </Router>
    </div>
  );
}

export default App;
