import React, { useState } from 'react';
import './Tasks.css';

const Tasks = () => {
  const [tasks, setTasks] = useState([]);
  const [newTask, setNewTask] = useState({
    title: '',
    description: '',
    priority: 'medium',
    dueDate: '',
    category: 'personal'
  });
  const [showAddTask, setShowAddTask] = useState(false);

  const handleAddTask = (e) => {
    e.preventDefault();
    setTasks([...tasks, { ...newTask, id: Date.now(), completed: false }]);
    setNewTask({ title: '', description: '', priority: 'medium', dueDate: '', category: 'personal' });
    setShowAddTask(false);
  };

  const toggleTaskStatus = (taskId) => {
    setTasks(tasks.map(task => 
      task.id === taskId ? { ...task, completed: !task.completed } : task
    ));
  };

  return (
    <div className="tasks-container">
      <div className="tasks-header">
        <h1>Task Manager</h1>
        <button className="add-task-btn" onClick={() => setShowAddTask(true)}>
          + Add New Task
        </button>
      </div>

      {showAddTask && (
        <div className="add-task-form">
          <form onSubmit={handleAddTask}>
            <input
              type="text"
              placeholder="Task Title"
              value={newTask.title}
              onChange={(e) => setNewTask({...newTask, title: e.target.value})}
              required
            />
            <textarea
              placeholder="Description"
              value={newTask.description}
              onChange={(e) => setNewTask({...newTask, description: e.target.value})}
            />
            <div className="form-row">
              <select
                value={newTask.priority}
                onChange={(e) => setNewTask({...newTask, priority: e.target.value})}
              >
                <option value="high">High Priority</option>
                <option value="medium">Medium Priority</option>
                <option value="low">Low Priority</option>
              </select>
              <select
                value={newTask.category}
                onChange={(e) => setNewTask({...newTask, category: e.target.value})}
              >
                <option value="personal">Personal</option>
                <option value="work">Work</option>
                <option value="study">Study</option>
                <option value="health">Health</option>
              </select>
              <input
                type="date"
                value={newTask.dueDate}
                onChange={(e) => setNewTask({...newTask, dueDate: e.target.value})}
              />
            </div>
            <div className="form-actions">
              <button type="submit">Add Task</button>
              <button type="button" onClick={() => setShowAddTask(false)}>Cancel</button>
            </div>
          </form>
        </div>
      )}

      <div className="tasks-grid">
        <div className="task-column">
          <h2>High Priority</h2>
          {tasks.filter(task => task.priority === 'high').map(task => (
            <div key={task.id} className={`task-card ${task.completed ? 'completed' : ''}`}>
              <input
                type="checkbox"
                checked={task.completed}
                onChange={() => toggleTaskStatus(task.id)}
              />
              <div className="task-content">
                <h3>{task.title}</h3>
                <p>{task.description}</p>
                <div className="task-meta">
                  <span className={`category ${task.category}`}>{task.category}</span>
                  <span className="due-date">{task.dueDate}</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="task-column">
          <h2>Medium Priority</h2>
          {tasks.filter(task => task.priority === 'medium').map(task => (
            <div key={task.id} className={`task-card ${task.completed ? 'completed' : ''}`}>
              <input
                type="checkbox"
                checked={task.completed}
                onChange={() => toggleTaskStatus(task.id)}
              />
              <div className="task-content">
                <h3>{task.title}</h3>
                <p>{task.description}</p>
                <div className="task-meta">
                  <span className={`category ${task.category}`}>{task.category}</span>
                  <span className="due-date">{task.dueDate}</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="task-column">
          <h2>Low Priority</h2>
          {tasks.filter(task => task.priority === 'low').map(task => (
            <div key={task.id} className={`task-card ${task.completed ? 'completed' : ''}`}>
              <input
                type="checkbox"
                checked={task.completed}
                onChange={() => toggleTaskStatus(task.id)}
              />
              <div className="task-content">
                <h3>{task.title}</h3>
                <p>{task.description}</p>
                <div className="task-meta">
                  <span className={`category ${task.category}`}>{task.category}</span>
                  <span className="due-date">{task.dueDate}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Tasks;