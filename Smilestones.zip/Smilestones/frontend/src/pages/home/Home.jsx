import React, { useEffect } from 'react';
import Navbar from '../../components/navbar/Navbar';
import Mission from '../../components/mission/Mission';
import Carousel from '../../components/carousel/carousel';
import Reviews from '../../components/reviews/Reviews';
import AboutUs from '../../components/aboutUs/AboutUs';
import './Home.css';

const Home = () => {
  useEffect(() => {
    const pages = document.querySelectorAll('.book-page');
    pages.forEach((page, index) => {
      setTimeout(() => {
        page.classList.add('turn');
      }, 500 * index);
    });
  }, []);

  return (
    <div className="home">
      <Navbar />
      
      {/* Hero Section */}
      <section className="hero-section">
        <div className="hero-content">
          <h1>Track. Celebrate. Inspire.</h1>
          <h2>Welcome to Smilestones!</h2>
          <p>Your journey of achievements starts here</p>
          <button className="cta-button">Get Started</button>
        </div>
      </section>

      {/* Book Section */}
      <div className="book-container">
        <div className="book">
          <div className="book-page page-left"></div>
          <div className="book-page page-right"></div>
          <div className="book-content">
            <div className="content-wrapper">
              <h1>Welcome to Smilestones</h1>
              <p>Track your achievements, share your journey</p>
              <div className="feature-grid">
                <div className="feature-card">
                  <h3>Track Progress</h3>
                  <p>Monitor your daily achievements</p>
                </div>
                <div className="feature-card">
                  <h3>Share Success</h3>
                  <p>Celebrate with your community</p>
                </div>
                <div className="feature-card">
                  <h3>Stay Focused</h3>
                  <p>Keep your goals in sight</p>
                </div>
                <div className="feature-card">
                  <h3>Get Inspired</h3>
                  <p>Learn from others' journeys</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Carousel Section */}
      <div className="carousel-wrapper">
        <Carousel />
      </div>

      {/* Mission Section */}
      <Mission />

      {/* Reviews Section */}
      <Reviews />

      {/* About Us Section */}
      <AboutUs />
    </div>
  );
};

export default Home;