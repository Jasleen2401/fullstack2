import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Auth.css';

const Auth = () => {
  const [isSignUp, setIsSignUp] = useState(false);
  const navigate = useNavigate();

  const handleGoogleAuth = () => {
   
    navigate('/home');
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    navigate('/home');
  };

  return (
    <div className="auth-container">
      <div className="auth-left">
      
      </div>
      <div className="auth-right">
        <div className="auth-form">
          <h2>Celebrate Every Step<br />With Smilestones</h2>
          
          <button className="google-btn" onClick={handleGoogleAuth}>
            <img src="https://developers.google.com/identity/images/g-logo.png" alt="Google" />
            Continue with Google
          </button>

          <div className="divider">Or</div>

          <form onSubmit={handleSubmit}>
            {isSignUp && (
              <input type="text" placeholder="Full Name" required />
            )}
            <input type="email" placeholder="Email" required />
            <input type="password" placeholder="Password" required />
            {isSignUp && (
              <input type="password" placeholder="Confirm Password" required />
            )}
            <a href="#" className="forgot-password">Forgot password?</a>
            <button type="submit" className="submit-btn">
              {isSignUp ? 'Sign Up' : 'Login'}
            </button>
          </form>

          <div className="auth-switch">
            {isSignUp ? "Already have an account? " : "Don't have an account? "}
            <button 
              className="switch-btn"
              onClick={() => setIsSignUp(!isSignUp)}
            >
              {isSignUp ? 'Login' : 'Sign Up'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Auth;